#!/bin/bash

# Remember to add executable rights to this bash script
# By using: chmod +x start.sh

# To use this .sh => ./start.sh

docker compose -f docker-compose.yaml up -d --build